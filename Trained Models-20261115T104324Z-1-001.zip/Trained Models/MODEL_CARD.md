# PHC351 model card

## Scope and artifacts

This academic project contains separate gravitational-wave and acoustic experiments. GW strain and microphone audio are not jointly measured or fused. The acoustic experts are two representations of the same audio; no paired vibration sensors were collected.

Drive weights: `Trained Models/MoE_training_v1/gw_checkpoints.zip`, `acoustic_checkpoints.zip`, and `Trained Models/Acoustic_improvement_v2/improved_models_00.zip`. Restore with the release indexes; the executable working copy places weights under `reports/` as expected by the code. Checkpoint paths and SHA-256 values for acoustic candidates are recorded in `FINAL_EVALUATION_PLAN.json` inside the improved results release. Use `torch.load(..., weights_only=True)` through the provided inference helpers.

## Implemented models

**Waveform expert:** learned analysis/synthesis filters, residual dilated temporal convolutions, signal/noise masks and waveform reconstruction. **Baseline spectral expert:** compact complex-STFT masking network. **Improved spectral expert:** complex-mask U-Net with skip connections and temporal attention; acoustic STFT window 256 samples and hop 64. **Joint model:** feature/quality-based softmax gate combines expert estimates and detection features. It receives observable input statistics, not the reference SNR.

Experts are trained separately before frozen-expert fusion and joint fine-tuning. Reconstruction uses positive-target normalised waveform error, negative/silence suppression, spectral error, noise reconstruction, mixture consistency and detection loss. Controls include fixed averaging and additional single-expert training. Additional acoustic classification uses a 40-band log-mel CNN–BiGRU with attention; it does not itself provide a source reconstruction.

The selected acoustic detector, `hybrid_detector_ensemble`, equally averages raw logits from three `joint_recall` models and three base `raw_crnn` models, then applies sigmoid and a fixed threshold. This is not an equal average of sigmoid probabilities. The selected reconstructor is separately chosen as `35162_joint_recall`. Additional ranking-adapted detectors are experimental controls, not the selected six-model ensemble. Fine-tuning seeds 35161, 35162 and 35163 share pretrained initialisation.

The selected acoustic reconstructor's mean gate weights are approximately 0.0547 waveform and 0.9453 spectral. This does not establish balanced specialisation. In GW, the extra-trained waveform control outperforms joint fusion.

## Data and input contracts

| Experiment | Input | Reference |
|---|---|---|
| GW augmented v3 | finite `(N,8192,1)`, 2048 Hz, 4 s | known simulated injection after shared background-PSD whitening and filtering |
| Acoustic | finite `(N,16384,1)`, 8192 Hz, 2 s | propagated source excerpt, conditioned and scaled with the same final mixture gain |

GW: 6,000 training, 600 validation, 600 test; 300 positive test injections. The data reuse one H1 background recording in disjoint time partitions. Acoustic training: 6,000 corrected ESC mixtures plus 3,000 FSD mixtures. Development: 600 ESC plus 600 FSD mixtures; operating thresholds use the FSD validation subset. The new test has 500 positive and 500 noise-only mixtures reusing 240 recordings. Source IDs/uploader groups are separated for the supplementary splits. Exact-content duplicate checks do not exclude every near-duplicate.

Foreground categories include cough, cry, knock, breathing, speech and shout. Source labels are weak and some contain animal co-labels or synthetic speech. A target can retain original source contamination, so it is not an anechoic ground truth or proof of a human presence.

## Frozen results

| Result | Value |
|---|---:|
| Acoustic fixed threshold | 0.8398472984240973 |
| Acoustic accuracy / recall / noise FPR | 0.810 / 0.756 / 0.136 |
| Precision / ROC AUC | 0.847534 / 0.899928 |
| TP / FN / FP / TN | 378 / 122 / 68 / 432 |
| Acoustic reconstruction overlap / NMSE | 0.757744 / 0.472459 |
| Adapted original matched-test accuracy / recall / FPR | 0.683 / 0.504 / 0.138 |
| GW extra-trained waveform overlap / NMSE | 0.870272 / 0.225023 |
| GW joint fusion overlap / NMSE | 0.865278 / 0.229965 |

The earlier 57.7% recall was measured on a different ESC cohort and is not directly comparable with the new test. The foreground-uploader bootstrap recall interval is 69.5–81.3%; the improvement over the adapted original is 19.6–30.7 percentage points. These are descriptive grouped intervals, not field-performance guarantees.

A diagnostic scan of 1,237 overlapping windows from 109 usable clips covered 1,346 seconds of unique audio and produced 79 merged alert episodes. Its conditioning differs from random-mixture generation. It is short, reuses held-out background sources and does not establish an independent false-alerts-per-hour rate in disasters.

## Intended use and limitations

Intended use is academic study of controlled reconstruction, representation comparisons and sound-category detection. The model is offline and noncausal, uses bidirectional processing, has no measured end-to-end latency, and does not localise people. There is no paired sensor validation, measured rubble propagation, independent disaster-site evaluation or evidence of reliable live-person confirmation. Detection scores are uncalibrated model outputs, not survivor probabilities.

A real-event GW illustration has no clean measured target and is qualitative. Quantitative GW scores use injections; the experiment does not claim a new astrophysical detection.

## Reproduction

Read `Code/README_RUN_AND_EVALUATE.md`. The new replay helper verifies selected checkpoint digests and retains the frozen acoustic evaluation plan. Replaying the released benchmark is not new independent validation. New model/threshold selection should use development data and reserve a new external test set. Numerical checks from the directory audit are in `Reports/SUBMISSION_HELPERS_VERIFICATION.json`.

Source licences remain with the original ESC and FSD manifests. ESC source data are for academic/non-commercial use under their recorded licence; FSD recordings have per-clip terms. CRED, EQTransformer and DeepDenoiser are prior architectural references, not trained reproductions claimed by this project.
