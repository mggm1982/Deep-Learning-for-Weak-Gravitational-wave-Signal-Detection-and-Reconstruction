"""Reproducible H1 detection/reconstruction dataset; see README for conventions."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
import time

import h5py
import lal
import lalsimulation as ls
import numpy as np
import scipy
from scipy.signal import butter, sosfiltfilt, welch, fftconvolve
from scipy.signal.windows import tukey

FS = 4096
N = 12 * FS
KEEP = slice(4 * FS, 8 * FS)
EVENT_GPS = 1126259462.4
SOURCE_URL = "https://gwosc.org/GW150914data/H-H1_LOSC_4_V2-1126257414-4096.hdf5"
SOURCE_MD5 = "7b40e31c5092b40bb7999e36ad9a6612"
SPLITS = {"train": (0, 2400, 1050), "validation": (2400, 3232, 225),
          "test": (3232, 4096, 225)}


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_source(path):
    with h5py.File(path, "r") as f:
        ds = f["strain/Strain"]
        strain = np.asarray(ds[:], dtype=np.float64)
        fs = round(1 / float(ds.attrs["Xspacing"]))
        gps = float(ds.attrs["Xstart"])
        quality = np.asarray(f["quality/simple/DQmask"][:], dtype=np.int64)
        injections = np.asarray(f["quality/injections/Injmask"][:], dtype=np.int64)
    assert fs == FS and len(strain) == 4096 * FS
    assert quality.shape == injections.shape == (4096,)
    # DATA + CBC CAT1/2/3 and no CBC/BURST/DETCHAR hardware injections.
    good = ((quality & 15) == 15) & ((injections & 7) == 7)
    good &= np.isfinite(strain.reshape(-1, FS)).all(axis=1)
    seconds = gps + np.arange(len(good))
    good &= (seconds + 1 <= EVENT_GPS - 32) | (seconds >= EVENT_GPS + 32)
    return strain, gps, good, quality, injections


def make_conditioner(background):
    f, p = welch(background, fs=FS, window="hann", nperseg=4*FS,
                 noverlap=2*FS, detrend="constant", scaling="density",
                 average="median")
    frequencies = np.fft.rfftfreq(N, 1 / FS)
    psd = np.maximum(np.interp(frequencies, f, p), np.finfo(float).tiny)
    assert np.isfinite(psd).all() and (psd > 0).all()
    # Finite support whitening prevents cross-split access and FFT wraparound.
    taper = np.zeros_like(frequencies)
    band = (frequencies >= 25) & (frequencies <= 550)
    taper[band] = 1
    low = (frequencies >= 25) & (frequencies < 30)
    high = (frequencies > 500) & (frequencies <= 550)
    taper[low] = np.sin((frequencies[low]-25)/5*np.pi/2)**2
    taper[high] = np.cos((frequencies[high]-500)/50*np.pi/2)**2
    impulse = np.fft.fftshift(np.fft.irfft(taper*np.sqrt(2/FS)/np.sqrt(psd), n=N))
    half = 2*FS
    kernel = impulse[N//2-half:N//2+half+1] * tukey(2*half+1, .2)
    sos = butter(4, [30, 500], btype="bandpass", fs=FS, output="sos")

    def condition(x):
        z = fftconvolve(np.asarray(x, dtype=np.float64), kernel, mode="same")
        return sosfiltfilt(sos, z)[KEEP]

    return frequencies, psd, kernel, sos, condition


def optimal_snr(h, psd):
    freq = np.fft.rfftfreq(len(h), 1/FS)
    band = (freq >= 30) & (freq <= 500)
    hf = np.fft.rfft(h) / FS
    return float(np.sqrt(4*(FS/len(h))*np.sum(np.abs(hf[band])**2 / psd[band])))


def generate_waveform(rng, peak_in_output):
    m1, m2 = sorted(rng.uniform(20, 50, 2), reverse=True)
    inclination = float(np.arccos(rng.uniform(-1, 1)))
    phase = float(rng.uniform(0, 2*np.pi))
    polarization = float(rng.uniform(0, np.pi))
    hp, hc = ls.SimInspiralChooseTDWaveform(
        m1*lal.MSUN_SI, m2*lal.MSUN_SI, 0, 0, 0, 0, 0, 0,
        400e6*lal.PC_SI, inclination, phase, 0, 0, 0, 1/FS, 30, 30,
        lal.CreateDict(), ls.IMRPhenomD)
    # Simplified single-detector polarization response; no network sky geometry.
    h = np.cos(2*polarization)*hp.data.data + np.sin(2*polarization)*hc.data.data
    assert np.isfinite(h).all() and np.max(np.abs(h)) > 0
    peak = int(np.argmax(np.abs(h)))
    desired_peak = 4*FS + peak_in_output
    aligned = np.zeros(N, dtype=np.float64)
    offset = desired_peak-peak
    src0, dst0 = max(0, -offset), max(0, offset)
    count = min(len(h)-src0, N-dst0)
    aligned[dst0:dst0+count] = h[src0:src0+count]
    energy_retained = np.sum(aligned[KEEP]**2) / np.sum(h**2)
    assert energy_retained > .99, ("Insufficient retained waveform energy", energy_retained)
    assert np.argmax(np.abs(aligned)) == desired_peak
    # Keep the original epoch and peak to distinguish amplitude peak from tc.
    params = dict(mass1_msun=float(m1), mass2_msun=float(m2),
                  inclination_rad=inclination, phase_rad=phase,
                  polarization_rad=polarization, reference_distance_mpc=400.,
                  waveform_epoch_seconds=float(hp.epoch), original_peak_index=peak,
                  original_peak_time_seconds=float(hp.epoch)+peak/FS,
                  original_length=len(h), retained_energy_fraction=float(energy_retained))
    return aligned, params


def build(source, output, seed=35142, smoke=False):
    output.mkdir(parents=True, exist_ok=True)
    assert hashlib.md5(source.read_bytes()).hexdigest() == SOURCE_MD5, "Source differs from GWOSC's published checksum"
    strain, gps, good, dq, inj = read_source(source)
    rng = np.random.default_rng(seed)
    manifest = dict(version="v2", seed=seed, detector="H1", sample_rate=FS,
                    duration_seconds=4, context_seconds=12, crop_seconds=[4,8],
                    source_file=source.name, source_url=SOURCE_URL,
                    source_sha256=sha256(source), source_start_gps=gps,
                    source_published_md5=SOURCE_MD5,
                    exclusion_gps=[EVENT_GPS-32, EVENT_GPS+32],
                    snr_convention="optimal unconditioned injected strain, one-sided PSD, 30-500 Hz",
                    conditioning="4s truncated FIR ASD whitening sqrt(2/fs), then order-4 zero-phase Butterworth 30-500Hz; crop 4s edges",
                    approximant="IMRPhenomD", spins="zero", mass_range_msun=[20,50],
                    signal_response="random linear combination of plus/cross; single-detector simplified response",
                    reconstruction_target="conditioned injected clean strain in identical units to X",
                    packages=dict(python=platform.python_version(), numpy=np.__version__,
                                  scipy=scipy.__version__, h5py=h5py.__version__,
                                  lal=lal.__version__, lalsimulation=ls.__version__),
                    splits={}, shards=[])
    all_rows=[]
    for split, (lo, hi, nsignal) in SPLITS.items():
        if smoke:
            nsignal=3
        # PSD lives in its own 128s region in this split, never in model windows.
        psd_start = next((s for s in range(lo+4,hi-140) if good[s:s+128].all()), None)
        assert psd_start is not None
        psd_end=psd_start+128
        frequencies, psd, kernel, sos, condition = make_conditioner(strain[psd_start*FS:psd_end*FS])
        candidates = [s for s in range(lo+4,hi-16)
                      if good[s:s+12].all() and (s+12 <= psd_start-4 or s >= psd_end+4)]
        assert len(candidates) >= 2*nsignal, (split, len(candidates), 2*nsignal)
        starts=rng.choice(candidates,2*nsignal,replace=False)
        labels=rng.permutation(np.r_[np.ones(nsignal,int),np.zeros(nsignal,int)])
        np.savez_compressed(output/f"{split}_conditioning.npz", frequencies=frequencies,
                            psd=psd, whitening_kernel=kernel, bandpass_sos=sos,
                            source_start_gps=gps, psd_start_gps=gps+psd_start,
                            psd_end_gps=gps+psd_end, sample_rate=FS)
        manifest["splits"][split]=dict(source_offset_seconds=[lo,hi],
            source_gps=[gps+lo,gps+hi], psd_gps=[gps+psd_start,gps+psd_end],
            candidate_windows=len(candidates), positive=nsignal, negative=nsignal,
            stride_seconds=1, overlap="up to 75% between 4s outputs; same split only")
        Xbuf=[]; ybuf=[]; rows=[]; shard_number=0
        for i,(start,label) in enumerate(zip(starts,labels)):
            noise=strain[start*FS:(start+12)*FS]
            h=np.zeros(N); params={}
            desired=measured=alpha=0.; peak_index=-1
            if label:
                peak_index=int(rng.integers(int(2.25*FS),int(2.75*FS)))
                h,params=generate_waveform(rng,peak_index)
                desired=float(rng.uniform(5,20))
                alpha=desired/optimal_snr(h,psd)
                h*=alpha
                measured=optimal_snr(h,psd)
                assert abs(measured-desired) < 1e-10
            # Explicitly condition both mixture and target with the same operator.
            x=condition(noise+h); y=condition(h); n=condition(noise)
            assert np.isfinite(x).all() and np.isfinite(y).all()
            assert x.shape == y.shape == (4*FS,)
            linearity=float(np.max(np.abs((x-y)-n)))
            assert linearity < 1e-10
            conditioned_peak=int(np.argmax(abs(y))) if label else -1
            if label:
                assert abs(conditioned_peak-peak_index) / FS < .025
                assert np.linalg.norm(y)>0
            else:
                assert np.array_equal(y,np.zeros_like(y))
            row=dict(sample_id=f"{split}_{i:05d}", split=split, label=int(label),
                     waveform_id=f"{split}_wave_{i:05d}" if label else None,
                     noise_context_start_gps=gps+int(start),
                     noise_context_end_gps=gps+int(start)+12,
                     output_start_gps=gps+int(start)+4,
                     psd_id=f"{split}_conditioning.npz", target_snr=desired,
                     measured_optimal_snr=measured, injection_scale=alpha,
                     raw_peak_index=peak_index, conditioned_peak_index=conditioned_peak,
                     raw_peak_time_seconds=peak_index/FS if label else None,
                     conditioned_target_l2=float(np.linalg.norm(y)),
                     conditioned_noise_std=float(np.std(n)),
                     linearity_max_abs_error=linearity, **params)
            Xbuf.append(x.astype(np.float32)); ybuf.append(y.astype(np.float32)); rows.append(row)
            if len(rows)==250 or i==len(starts)-1:
                name=f"{split}_{shard_number:03d}.npz"
                np.savez_compressed(output/name, X=np.stack(Xbuf)[...,None],
                                    y=np.stack(ybuf)[...,None],
                                    labels=np.array([r['label'] for r in rows],np.int8),
                                    sample_ids=np.array([r['sample_id'] for r in rows]),
                                    sample_rate=FS)
                manifest["shards"].append(dict(file=name,split=split,rows=len(rows),
                                               sha256=sha256(output/name)))
                all_rows.extend(rows); Xbuf=[];ybuf=[];rows=[];shard_number+=1
            if (i+1)%100==0:
                print(f"{split}: {i+1}/{len(starts)} examples",flush=True)
        print(f"Finished {split}: {len(starts)}",flush=True)
    with open(output/"samples.jsonl","w") as f:
        for row in all_rows:
            f.write(json.dumps(row,allow_nan=False)+"\n")
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2,allow_nan=False)+"\n")
    np.savez_compressed(output/"source_quality.npz",quality_mask=dq,injection_mask=inj,
                        usable_seconds=good,source_start_gps=gps)
    return manifest


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--smoke",action="store_true")
    args=parser.parse_args()
    start=time.time()
    build(args.source,args.output,smoke=args.smoke)
    print(f"Generation finished in {time.time()-start:.1f}s")
