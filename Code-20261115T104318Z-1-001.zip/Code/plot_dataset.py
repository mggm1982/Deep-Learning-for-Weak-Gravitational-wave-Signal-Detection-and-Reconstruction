"""Produce static QA plots from all validation metrics and saved examples."""
import json
from pathlib import Path
import argparse
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/phc351-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def plot(output,figdir):
    figdir.mkdir(parents=True,exist_ok=True)
    rows=[json.loads(s) for s in (output/'samples.jsonl').read_text().splitlines()]
    fig,axes=plt.subplots(2,2,figsize=(12,8))
    for split,color in [('train','#2374AB'),('validation','#E58F2A'),('test','#4F9D69')]:
        positives=[r for r in rows if r['split']==split and r['label']]
        axes[0,0].hist([r['measured_optimal_snr'] for r in positives],bins=np.linspace(5,20,21),histtype='step',label=split,color=color)
        axes[0,1].hist([r['raw_peak_time_seconds'] for r in positives],bins=20,histtype='step',color=color)
        axes[1,0].scatter([r['noise_context_start_gps'] for r in rows if r['split']==split],
                          [r['conditioned_noise_std'] for r in rows if r['split']==split],s=3,label=split,color=color)
        axes[1,1].scatter([r['mass1_msun'] for r in positives],[r['mass2_msun'] for r in positives],s=4,label=split,color=color)
    for ax in axes.flat: ax.grid(alpha=.2)
    axes[0,0].set(xlabel='Optimal injected SNR (30–500 Hz)',ylabel='Waveform count');axes[0,0].legend()
    axes[0,1].set(xlabel='Merger peak within output (s)',ylabel='Waveform count')
    axes[1,0].set(xlabel='Noise context start (GPS)',ylabel='Conditioned noise standard deviation')
    axes[1,1].set(xlabel='Primary mass (solar masses)',ylabel='Secondary mass (solar masses)')
    fig.suptitle('PHC351 v2 — all 1,500 injected waveforms / 3,000 examples')
    fig.tight_layout();fig.savefig(figdir/'dataset_validation.png',dpi=160);plt.close(fig)
    fig,axes=plt.subplots(3,1,figsize=(12,9))
    for ax,split in zip(axes,['train','validation','test']):
        d=np.load(output/f'{split}_000.npz',allow_pickle=False)
        i=int(np.flatnonzero(d['labels']==1)[0]);x=d['X'][i,:,0];y=d['y'][i,:,0]
        t=np.arange(len(x))/4096
        ax.plot(t,x,lw=.5,alpha=.6,label='Noisy input')
        ax.plot(t,y,lw=1.1,color='#E05252',label='Clean reconstruction target')
        ax.set(xlabel='Time within output (s)',ylabel='Conditioned amplitude',title=f'{split}: {d["sample_ids"][i]}')
        ax.legend(loc='upper left');ax.grid(alpha=.2)
    fig.tight_layout();fig.savefig(figdir/'input_target_examples.png',dpi=160);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--figures',type=Path,required=True);a=p.parse_args();plot(a.output,a.figures)
