# PHC351 acoustic improvement v2

This experiment separates better detection from threshold changes, and separates
expanded label coverage from improvement on the original cough/cry/knock task.
The prior GW release is preserved. This is an acoustic reference-mixture study;
the two experts process the same audio, not two independently measured sensors.

## Training design

- Existing ESC training mixtures: 6,000. Additional FSD mixtures: 3,000. Each
  epoch samples 6,000 examples with equal weight for the two source corpora.
- Development: 600 original ESC plus 600 FSD mixtures. Checkpoints use partial
  ROC AUC at 10% FPR, AP, recall at 10% FPR and waveform overlap. Detection
  selection across models excludes overlap and uses FSD development only.
- Operating thresholds use FSD development only. Primary policy maximizes recall
  with at most 10% validation noise-window FPR. Secondary policies target 90%
  validation recall and validation F2, plus stricter 1% and 5% validation-FPR
  policies. Actual test FPR is reported; 300 validation negatives provide limited
  evidence about very low false-alarm tails.
- Three fine-tuning seeds share pretrained ESC initialization. This measures
  fine-tuning variability, not independent pretraining variability.
- Experts train separately; fusion trains first with experts frozen, then
  jointly. Positive-weighted detection and hard-negative loss accompany
  waveform reconstruction, silence suppression and complex spectral losses.
- Architectures: adapted legacy waveform/tiny-spectral fusion; waveform TCN;
  complex-mask spectral U-Net with temporal attention; feature-level fusion
  with expert dropout; classification-only log-mel CNN/BiGRU attention.
- A spectral expert gets the same additional epoch allowance as joint tuning.
  This is an epoch/step control, not an equal-compute or equal-parameter claim.
- Joint and joint+CRNN raw-logit ensembles were declared before test access.
  Detector and reconstructor are selected separately on development.
  Detector-only three-CRNN and three-ranking-adapted ensembles are additional
  pre-test controls for whether reconstruction-model fusion contributes.
- After seeing the gap between mixed and FSD-only validation, a pre-test
  classifier stage emphasizes new FSD data (75%, with 25% original replay) and
  adds a hard-negative pairwise ranking loss. It uses 4,000 samples/epoch for up
  to six extra epochs per seed, selected on FSD validation. This has an extra
  training budget; gains cannot be attributed solely to architecture. Declaration
  and additional development records are frozen before test loading.

## Audit and evaluation order

`download_fsd.py` pins the public source revision and records per-clip licenses.
All ESC recording IDs and known uploaders of the used ESC subset are excluded;
new train/validation/test uploader groups are disjoint. `build_fsd_mixtures.py`
recomputes every saved mixture and target from the source parameters, checks SNR,
shapes, finite values and common gains, then writes `LOCKED_TEST.json`.
`audit_audio_duplicates.py` checks decoded, resampled, peak-normalized content
across the selected ESC and FSD recordings. Its passing report is required by
the evaluator; it does not rule out cropped or re-encoded near-duplicates.

`run_development.py` finishes all candidates before writing `FROZEN_SELECTION.json`.
`evaluate_locked.py` freezes model/threshold choices and hashes in
`FINAL_EVALUATION_PLAN.json` before loading the test tensors. The 1,000 mixtures
reuse 240 held-out recordings. The original model is recalibrated on exactly the
same new validation set and evaluated on exactly the same new test mixture set.

`summarize_results.py` reads saved predictions only. It reports the original
three-class subset, expanded classes, SNR bins, all seed results and descriptive
uploader-cluster intervals. `continuous_background.py` is a post-freeze diagnostic
on the same held-out background sources; it is not additional independent field
validation. `verify_release.py` checks checkpoint reload and deployed-helper
agreement. Archives preserve project-relative paths, member hashes and CRCs.

## Restore and use

Open `PHC351_Acoustic_Improvement_v2.ipynb` from the existing Drive Code folder.
It verifies archive hashes, restores the project into a Colab cache and saves
inference outputs directly into the existing Drive Results folder.

Local commands after restoring all prerequisites:

```sh
python code/improvement_v2/run_development.py
python code/improvement_v2/audit_audio_duplicates.py
python code/improvement_v2/evaluate_locked.py
python code/improvement_v2/summarize_results.py
python code/improvement_v2/infer_selected.py --input conditioned.npz --output prediction.npz
```

Repeat training needs the original v1 ESC data/checkpoints and both shared
pretraining checkpoints as well as new training archives. Completed stages are
cached; use a separate project/run for genuinely new experiments. Do not retune
against the released test set and call it fresh again.

Inputs are finite mono `(N,16384,1)` arrays at 8192 Hz. Raw external audio needs
the documented conditioning adapter. Models are offline/noncausal. Scores are
not calibrated survivor probabilities. Source labels are weak, the foreground
references retain original contamination, and synthetic impulse responses do
not establish performance through rubble. Continuous external recordings,
measured propagation, event annotations, device robustness and supervised field
validation are required before rescue use. Per-clip licensing applies.
