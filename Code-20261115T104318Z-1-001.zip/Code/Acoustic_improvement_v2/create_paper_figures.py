"""Descriptive figures from frozen saved results; no fitting or model selection."""
import csv,hashlib,json,os,shutil,zipfile
from pathlib import Path
ROOT=next((p for p in [Path.cwd(),*Path(__file__).resolve().parents] if (p/'reports/improvement_v2/FINAL_EVALUATION_PLAN.json').exists()),None)
if ROOT is None:raise RuntimeError('Run from the restored PHC351 project containing reports/improvement_v2/FINAL_EVALUATION_PLAN.json')
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.ticker import PercentFormatter
from sklearn.metrics import roc_curve,roc_auc_score,precision_recall_curve,average_precision_score,confusion_matrix
REPORT=ROOT/'reports/improvement_v2';OUT=REPORT/'paper_figures_v1'
plt.rcParams.update({'font.size':10,'pdf.fonttype':42,'ps.fonttype':42})
def save(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=300,bbox_inches='tight')
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
def main():
    OUT.mkdir(exist_ok=True)
    plan=json.loads((REPORT/'FINAL_EVALUATION_PLAN.json').read_text());results=json.loads((REPORT/'fresh_test_results.json').read_text())
    analysis=json.loads((REPORT/'analysis.json').read_text());selected=plan['selected_detector'];legacy=plan['selected_legacy_control']
    assert selected=='hybrid_detector_ensemble','Use the frozen release selection, not a test-selected model'
    with np.load(REPORT/'hybrid_ensemble_fresh_predictions.npz') as d:y=d['labels'];p=d['probabilities']
    curves=[('Original v1, recalibrated','baseline_fresh_predictions.npz'),
            ('Original architecture, adapted',legacy+'_fresh_predictions.npz'),
            ('Selected hybrid','hybrid_ensemble_fresh_predictions.npz')]
    fig,axes=plt.subplots(1,2,figsize=(11,4.5))
    for label,file in curves:
        with np.load(REPORT/file) as d:
            assert np.array_equal(y,d['labels']);prob=d['probabilities']
        fpr,tpr,_=roc_curve(y,prob);precision,recall,_=precision_recall_curve(y,prob)
        axes[0].plot(fpr,tpr,label=f'{label} (AUC {roc_auc_score(y,prob):.3f})')
        axes[1].plot(recall,precision,label=f'{label} (AP {average_precision_score(y,prob):.3f})')
    axes[0].set(xlim=(0,.4),ylim=(0,1),xlabel='Noise-window false-positive fraction',ylabel='Recall',title='ROC: fresh source-disjoint mixtures')
    axes[1].axhline(y.mean(),color='gray',ls=':',lw=1)
    axes[1].set(xlim=(0,1),ylim=(0,1),xlabel='Recall',ylabel='Precision',title='Precision–recall: balanced test set')
    for ax in axes:ax.legend(fontsize=7,loc='lower left');ax.grid(alpha=.2)
    fig.tight_layout();save(fig,'roc_precision_recall')

    threshold=results[selected]['operating_points']['fpr_0.1']['threshold'];matrix=confusion_matrix(y,p>=threshold,labels=[0,1]);fractions=matrix/matrix.sum(1,keepdims=True)
    fig,ax=plt.subplots(figsize=(6,5));im=ax.imshow(fractions,cmap='Blues',vmin=0,vmax=1)
    for i in range(2):
        for j in range(2):ax.text(j,i,f'{matrix[i,j]}\n({fractions[i,j]:.1%} of row)',ha='center',va='center',fontsize=13,color='white' if fractions[i,j]>.6 else 'black')
    ax.set(xticks=[0,1],xticklabels=['No alert','Alert'],yticks=[0,1],yticklabels=['Task-negative noise','Reference foreground'],xlabel='Predicted',ylabel='Reference label',title=f'Selected hybrid: fixed threshold {threshold:.5f}')
    fig.colorbar(im,ax=ax,label='Within-row fraction');fig.tight_layout();save(fig,'selected_confusion_matrix')

    family_labels={'legacy_adapted':'Original architecture, adapted','wave_recall':'Waveform TCN','spectral_unet':'Spectral U-Net',
        'raw_crnn':'CNN–BiGRU detector','fusion_frozen':'Frozen feature fusion','joint_recall':'Joint feature fusion',
        'spectral_control':'Spectral extra-training control','raw_fsd_tail':'Domain/ranking adapted detector'}
    table=[]
    for name,label in family_labels.items():
        r=analysis['seed_summary'][name]
        table.append(dict(model=label,kind='mean of 3 fine-tuning seeds',**{k:r[k]['mean'] for k in ['accuracy','recall','fpr']},
            **{k+'_sd':r[k]['sample_std'] for k in ['accuracy','recall','fpr']}))
    for key,label in [('v1_recalibrated','Original v1, recalibrated'),(selected,'Selected six-model hybrid')]:
        m=results[key]['operating_points']['fpr_0.1'];table.append(dict(model=label,kind='single frozen system',**{k:m[k] for k in ['accuracy','recall','fpr']},accuracy_sd=0,recall_sd=0,fpr_sd=0))
    fig,axes=plt.subplots(1,3,figsize=(13,6.5),sharey=True);positions=np.arange(len(table))
    for ax,metric,title in zip(axes,['accuracy','recall','fpr'],['Accuracy','Recall','Noise false-positive fraction']):
        colors=['#de7a22' if r['model']=='Selected six-model hybrid' else '#487aa1' for r in table]
        ax.barh(positions,[r[metric] for r in table],xerr=[r[metric+'_sd'] for r in table],color=colors,alpha=.9,capsize=3)
        ax.set(title=title,xlim=(0,.25 if metric=='fpr' else 1));ax.xaxis.set_major_formatter(PercentFormatter(1));ax.grid(axis='x',alpha=.2)
    axes[0].set_yticks(positions,[r['model'] for r in table]);axes[0].invert_yaxis()
    fig.suptitle('Fresh test comparison — thresholds selected on validation',fontsize=13)
    fig.text(.52,.015,'Error bars: sample SD across 3 fine-tuning seeds; not confidence intervals. Orange: selected ensemble.',ha='center',fontsize=8)
    fig.tight_layout(rect=[0,.045,1,.96]);save(fig,'model_family_comparison')
    with (OUT/'model_family_comparison.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)

    fig,axes=plt.subplots(2,2,figsize=(11,6.5))
    for row,(name,title) in enumerate([('joint_recall','Joint waveform/spectral model'),('raw_crnn','CNN–BiGRU detector')]):
        for seed in [35161,35162,35163]:
            h=json.loads((REPORT/f'seed_{seed}'/f'{name}_history.json').read_text());epoch=[r['epoch'] for r in h]
            axes[row,0].plot(epoch,[r['train_loss'] for r in h],marker='.',label=str(seed))
            axes[row,1].plot(epoch,[r['validation']['auc'] for r in h],marker='.',label=str(seed))
        axes[row,0].set(title=title+' — training objective',xlabel='Epoch within stage',ylabel='Training loss')
        axes[row,1].set(title=title+' — development',xlabel='Epoch within stage',ylabel='Combined ESC/FSD validation AUC',ylim=(.85,1))
        for ax in axes[row]:ax.grid(alpha=.2);ax.legend(title='Fine-tuning seed',fontsize=8)
    fig.tight_layout();save(fig,'selected_component_training_curves')

    fig,ax=plt.subplots(figsize=(16,8.5));ax.set(xlim=(0,16),ylim=(0,8.5));ax.axis('off')
    def box(x,y,w,h,text,color='#eaf1f8',size=10):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',facecolor=color,edgecolor='#37546b',lw=1.4))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size)
    def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=15,color='#37546b',lw=1.5))
    ax.text(8,8.2,'Frozen selected pipeline: acoustic detection + separate waveform reconstruction',ha='center',fontsize=16,weight='bold')
    box(.3,3.6,2.3,1.25,'Conditioned mono\naudio: 2 s, 8192 Hz\ninput-derived RMS gain',size=9)
    box(3.25,6.0,3,1.1,'Waveform expert\nlearned encoder + residual TCN')
    box(3.25,4.1,3,1.2,'Spectral expert\ncomplex STFT masks\nU-Net + temporal attention')
    box(3.25,1.3,3,1.3,'Separate detector\nlog-mel CNN + BiGRU\nattention pooling')
    box(7,4.8,2.7,1.5,'Embeddings + input strength\n+ estimated expert quality\nlearned gate + detection head')
    box(10.3,5.05,2.1,1.15,'Joint logits × 3\nfine-tuning seeds')
    box(10.3,1.4,2.1,1.15,'CRNN logits × 3\nfine-tuning seeds')
    box(13,3.0,2.5,1.65,'Mean six raw logits\n→ sigmoid\n→ fixed threshold\n0.83985',color='#fff0dd')
    box(7,7,5.4,.75,'Reconstruction: one selected joint checkpoint (seed 35162)\nweighted expert waveforms; restore input amplitude',color='#e6f2e8',size=10)
    for a,b in [((2.6,4.65),(3.25,6.55)),((2.6,4.3),(3.25,4.7)),((2.6,3.8),(3.25,1.95)),
                ((6.25,6.55),(7,5.95)),((6.25,4.7),(7,5.15)),((9.7,5.55),(10.3,5.55)),
                ((6.25,1.95),(10.3,1.95)),((12.4,5.55),(13,4.2)),((12.4,1.95),(13,3.45)),((8.35,6.3),(8.35,7))]:arrow(a,b)
    ax.text(8,.65,'Both experts use the same audio; this is not measured audio–vibration sensor fusion.\nSeeds share pretrained initialization. CRNN outputs are detection scores, not reconstructions.\nGW reconstruction remains in its separate preserved release. Scores do not confirm a live trapped person.',ha='center',va='center',fontsize=10)
    save(fig,'selected_model_architecture')

    for name in ['fresh_test_comparison.png','development_auc_curves.png','reconstruction_examples.png']:
        shutil.copy2(REPORT/name,OUT/name)
    captions='''# Figure guide — frozen acoustic improvement release

These are descriptive figures from already-saved predictions and training histories. No training, threshold tuning or model selection was repeated for these figures.

- **roc_precision_recall:** untouched v1, validation-selected adapted original architecture, and selected hybrid on exactly the same fresh 1,000 mixtures. Precision depends on the test's 50% foreground prevalence; it is not field precision.
- **selected_confusion_matrix:** rows are true task labels, columns are predicted alerts. Threshold was selected on FSD validation, not test.
- **model_family_comparison:** model families show mean ± sample SD across three fine-tuning seeds. The selected ensemble and untouched v1 are single systems without seed error bars. These SDs are not confidence intervals, and training budgets differ.
- **selected_component_training_curves:** stage training losses and combined ESC/FSD validation AUC for the joint and raw recurrent components. Losses differ across architectures and must not be compared as a common accuracy measure.
- **selected_model_architecture:** actual selected six-checkpoint logit ensemble and separate selected reconstructor. The two experts view the same audio. The CRNN has no reconstruction head. The selected joint gate favors spectral processing (~94.5% mean weight); balanced specialization is not established.
- **fresh_test_comparison:** original existing ROC/SNR figure, comparing untouched recalibrated v1 with the upgrade; original v1 learned only three foreground categories.
- **development_auc_curves:** existing three-seed stage validation AUC curves; these are not test curves.
- **reconstruction_examples:** the first available positives among the fixed first eight held-out examples. Targets are reference foreground recordings with their original contamination, not laboratory-clean speech.

## Reading the results

The frozen hybrid achieved 81.0% accuracy, 75.6% recall and 13.6% noise-window FPR. The adapted original control achieved 68.3%, 50.4% and 13.8%, respectively. These comparisons use the new cohort; the earlier 57.7% recall came from a different test set.

The 1,000 mixtures reuse 240 reference recordings. Uploader groups are excluded across splits; source-cluster intervals are in analysis.json. The sound categories are cough, crying, knocking, breathing, speech and shouting, with weak labels and documented co-label confounds. Category detection does not establish live-human presence.

The background diagnostic produced 79 merged alerts in 22.4 analyzed minutes of short public task-negative clips. They are the same held-out background sources, not independent disaster-field hours. This alert burden is a serious deployment limitation. Keep the test frozen; use new manually annotated continuous validation/test sources for further improvement.

New figures are provided as PNG (300 dpi) and vector PDF. The three earlier PNGs retain their original resolution. model_family_comparison.csv contains plotted values. create_paper_figures.py reproduces this supplement from the frozen release.
'''
    (OUT/'FIGURE_GUIDE.md').write_text(captions)
    shutil.copy2(Path(__file__),OUT/'create_paper_figures.py')
    provenance={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [REPORT/'FINAL_EVALUATION_PLAN.json',REPORT/'fresh_test_results.json',REPORT/'analysis.json']}
    (OUT/'figure_provenance.json').write_text(json.dumps(dict(source_sha256=provenance,test_already_evaluated=True,selection_or_training_repeated=False),indent=2)+'\n')
    bundle=REPORT/'paper_figures_v1.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):z.write(p,p.name)
    with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
    print(json.dumps(dict(files=[p.name for p in OUT.iterdir()],bundle=str(bundle),bytes=bundle.stat().st_size),indent=2))
if __name__=='__main__':main()
