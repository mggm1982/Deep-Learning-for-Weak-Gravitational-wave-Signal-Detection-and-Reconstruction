"""Read back every saved sample and verify against its source and waveform parameters."""
import argparse
import json
from pathlib import Path

import h5py
import lal
import lalsimulation as ls
import numpy as np
from scipy.signal import fftconvolve, sosfiltfilt

from rebuild_dataset import FS, N, KEEP, EVENT_GPS, read_source, sha256


def validate(source, output):
    manifest=json.loads((output/'manifest.json').read_text())
    rows=[json.loads(line) for line in (output/'samples.jsonl').read_text().splitlines()]
    by_id={r['sample_id']:r for r in rows}
    assert len(by_id)==len(rows)
    assert sha256(source)==manifest['source_sha256']
    raw,gps,good,_,_=read_source(source)
    conditioning={}
    summary=dict(status='PASS', examples=0, positive=0, negative=0,
                 shape_per_example=[4*FS,1], sample_rate=FS,
                 all_arrays_finite=True, all_targets_recomputed=True,
                 all_mixtures_recomputed=True, zero_negative_targets=True,
                 unique_waveforms=True, no_cross_split_source_overlap=True,
                 event_excluded=True, checks=[], splits={})
    max_snr_error=0.;max_target_error=0.;max_input_error=0.;max_timing_error=0.
    seen_ids=set(); waveform_ids=set(); parameters_seen=set(); noise_contexts={s:[] for s in manifest['splits']}
    snrs=[];noise_stds=[];retained=[];peak_times=[];signal_norms=[]
    for split,info in manifest['splits'].items():
        with np.load(output/f'{split}_conditioning.npz',allow_pickle=False) as d:
            conditioning[split]={k:d[k].copy() for k in d.files}
        c=conditioning[split]
        assert np.isfinite(c['psd']).all() and (c['psd']>0).all()
        lo,hi=info['source_gps']; p0,p1=info['psd_gps']
        assert lo<=p0<p1<=hi
        for other,other_info in manifest['splits'].items():
            if other!=split:
                a,b=other_info['source_gps']
                assert hi<=a or lo>=b
        summary['splits'][split]=dict(examples=0,positive=0,negative=0,
                                     independent_source_gps=[lo,hi],psd_gps=[p0,p1])
    for shard in manifest['shards']:
        path=output/shard['file']; assert sha256(path)==shard['sha256']
        split=shard['split'];c=conditioning[split]; info=manifest['splits'][split]
        def condition(a):
            return sosfiltfilt(c['bandpass_sos'],fftconvolve(a,c['whitening_kernel'],mode='same'))[KEEP]
        with np.load(path,allow_pickle=False) as d:
            X,y,labels,ids=d['X'],d['y'],d['labels'],d['sample_ids']
            assert X.shape==y.shape==(shard['rows'],4*FS,1)
            assert X.dtype==y.dtype==np.float32
            assert np.isfinite(X).all() and np.isfinite(y).all()
            assert set(np.unique(labels)) <= {0,1}
            for j,sid in enumerate(ids):
                sid=str(sid); assert sid not in seen_ids;seen_ids.add(sid)
                r=by_id[sid];label=int(labels[j]);assert r['label']==label and r['split']==split
                a,b=r['noise_context_start_gps'],r['noise_context_end_gps']
                lo,hi=info['source_gps']; p0,p1=info['psd_gps']
                assert lo<=a<b<=hi and b-a==12
                assert b<=p0-4 or a>=p1+4
                assert b<=EVENT_GPS-32 or a>=EVENT_GPS+32
                start=round(a-gps);assert good[start:start+12].all()
                noise=raw[start*FS:(start+12)*FS]
                noise_contexts[split].append((a,b))
                h=np.zeros(N)
                if label:
                    assert r['waveform_id'] not in waveform_ids
                    waveform_ids.add(r['waveform_id'])
                    parameters=tuple(r[k] for k in ['mass1_msun','mass2_msun','inclination_rad','phase_rad','polarization_rad'])
                    assert parameters not in parameters_seen;parameters_seen.add(parameters)
                    hp,hc=ls.SimInspiralChooseTDWaveform(
                        r['mass1_msun']*lal.MSUN_SI,r['mass2_msun']*lal.MSUN_SI,
                        0,0,0,0,0,0,400e6*lal.PC_SI,r['inclination_rad'],r['phase_rad'],
                        0,0,0,1/FS,30,30,lal.CreateDict(),ls.IMRPhenomD)
                    wave=np.cos(2*r['polarization_rad'])*hp.data.data+np.sin(2*r['polarization_rad'])*hc.data.data
                    offset=4*FS+r['raw_peak_index']-int(np.argmax(abs(wave)))
                    s0,d0=max(0,-offset),max(0,offset);n=min(len(wave)-s0,N-d0)
                    h[d0:d0+n]=wave[s0:s0+n]*r['injection_scale']
                    # Independent SNR recomputation on the actual scaled strain.
                    f=np.fft.rfftfreq(N,1/FS);band=(f>=30)&(f<=500)
                    hf=np.fft.rfft(h)/FS
                    snr=float(np.sqrt(np.sum(4/(N/FS)*(hf[band].real**2+hf[band].imag**2)/c['psd'][band])))
                    err=abs(snr-r['target_snr']);assert err<1e-8
                    max_snr_error=max(max_snr_error,err);snrs.append(snr)
                    assert 5<=snr<=20
                    assert np.argmax(abs(h[KEEP]))==r['raw_peak_index']
                    timing_error=abs(int(np.argmax(abs(y[j,:,0])))-r['raw_peak_index'])/FS
                    assert timing_error<.025
                    max_timing_error=max(max_timing_error,timing_error)
                    retained.append(r['retained_energy_fraction']);assert retained[-1]>.99
                    peak_times.append(r['raw_peak_time_seconds'])
                    signal_norms.append(float(np.linalg.norm(y[j,:,0].astype(float))))
                else:
                    assert np.count_nonzero(y[j])==0
                expected_y=condition(h);expected_x=condition(noise+h)
                te=float(np.max(abs(y[j,:,0]-expected_y)))
                xe=float(np.max(abs(X[j,:,0]-expected_x)))
                assert np.allclose(y[j,:,0],expected_y,rtol=2e-6,atol=2e-6)
                assert np.allclose(X[j,:,0],expected_x,rtol=2e-6,atol=2e-6)
                max_target_error=max(max_target_error,te);max_input_error=max(max_input_error,xe)
                noise_stds.append(r['conditioned_noise_std'])
                summary['examples']+=1
                summary['positive' if label else 'negative']+=1
                summary['splits'][split]['examples']+=1
                summary['splits'][split]['positive' if label else 'negative']+=1
        print('Validated',shard['file'],flush=True)
    assert len(seen_ids)==len(rows)
    assert len(waveform_ids)==summary['positive']
    assert summary['positive']>=1500 and summary['negative']>=1500
    for split,contexts in noise_contexts.items():
        assert len(contexts)==len(set(contexts))
        sorted_contexts=sorted(contexts)
        summary['splits'][split]['overlapping_context_pairs']=sum(a[1]>b[0] for a,b in zip(sorted_contexts,sorted_contexts[1:]))
    def percentiles(values):
        return dict(zip(['min','p05','median','p95','max'],map(float,np.percentile(values,[0,5,50,95,100]))))
    summary.update(unique_waveform_count=len(waveform_ids),unique_noise_contexts=len(rows),
        snr=percentiles(snrs),conditioned_noise_std=percentiles(noise_stds),
        target_l2=percentiles(signal_norms),raw_peak_time_seconds=percentiles(peak_times),
        min_retained_waveform_energy=min(retained),max_snr_absolute_error=max_snr_error,
        max_target_float32_absolute_error=max_target_error,max_input_float32_absolute_error=max_input_error,
        max_conditioned_peak_shift_seconds=max_timing_error)
    summary['checks']=['all shard hashes and source hash','all array shapes/dtypes/finiteness',
        'regenerated clean targets from waveform parameters for every positive',
        'recomputed all conditioned mixtures from raw source strain',
        'PSD-based optimal injection SNR for all positives','zero targets for every negative',
        'merger timing and retained energy','unique waveform IDs and unique context starts',
        'disjoint source intervals and PSD regions across splits','quality/injection masks and event exclusion']
    (output/'validation_report.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps(summary,indent=2))
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    validate(a.source,a.output)
