"""Replay selected frozen models without changing their plan, thresholds or checkpoints."""
import argparse, hashlib, json, sys, tempfile
from pathlib import Path
import numpy as np

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def acoustic(root,device):
    sys.path.insert(0,str(root/'code/improvement_v2'))
    from infer_selected import predict
    from audit_thresholds import metrics
    from sklearn.metrics import roc_auc_score,average_precision_score
    out=root/'reports/improvement_v2';planpath=out/'FINAL_EVALUATION_PLAN.json';before=digest(planpath)
    plan=json.loads(planpath.read_text());inputs=[];targets=[];labels=[];fs=None
    for p in sorted((root/'data/acoustic_v2_fsd').glob('test_[0-9]*.npz')):
        with np.load(p,allow_pickle=False) as d:
            inputs.append(d['X']);targets.append(d['y']);labels.append(d['labels']);fs=int(d['sample_rate'])
    if not inputs:raise FileNotFoundError('Restore the acoustic test archives first')
    x=np.concatenate(inputs);y=np.concatenate(targets);label=np.concatenate(labels).astype(int)
    with tempfile.TemporaryDirectory() as tmp:
        a=Path(tmp)/'input.npz';b=Path(tmp)/'prediction.npz';np.savez_compressed(a,X=x,sample_rate=fs);predict(a,b,device)
        with np.load(b,allow_pickle=False) as d:
            scores=d['detection_score'];pred=d['reconstruction'];threshold=float(d['threshold'])
            assert pred.shape==x.shape and np.isfinite(pred).all() and np.isfinite(scores).all()
            assert np.allclose(pred+d['estimated_noise'],x,atol=1e-6)
    pos=label==1;yp=y[pos].reshape(pos.sum(),-1);pp=pred[pos].reshape(pos.sum(),-1)
    overlap=np.sum(yp*pp,axis=1)/np.maximum(np.linalg.norm(yp,axis=1)*np.linalg.norm(pp,axis=1),1e-12)
    nmse=np.sum((pp-yp)**2,axis=1)/np.maximum(np.sum(yp**2,axis=1),1e-12)
    result=dict(domain='acoustic',examples=len(label),device=device,detector=plan['selected_detector'],reconstructor=plan['selected_reconstructor'],
        threshold=threshold,operating_point=metrics(label,scores,threshold),roc_auc=float(roc_auc_score(label,scores)),
        average_precision=float(average_precision_score(label,scores)),overlap=float(overlap.mean()),normalized_mse=float(nmse.mean()),
        finite_outputs=True,residual_consistency=True)
    assert digest(planpath)==before,'Frozen plan changed'
    result['frozen_plan_unchanged']=True
    return result

def gw(root,device):
    sys.path.insert(0,str(root/'code/training'))
    from infer import predict
    checkpoint=root/'reports/training_v1/gw_augmented/wave_finetune_best.pt'
    if not checkpoint.exists():raise FileNotFoundError(checkpoint)
    overlaps=[];errors=[];examples=0
    with tempfile.TemporaryDirectory() as tmp:
        for source in sorted((root/'data/gw_augmented_v3').glob('test_[0-9]*.npz')):
            target=Path(tmp)/'prediction.npz';predict(checkpoint,source,target,'gw',device)
            with np.load(source,allow_pickle=False) as a,np.load(target,allow_pickle=False) as b:
                pos=a['labels']==1;y=a['y'][pos].reshape(pos.sum(),-1);p=b['reconstruction'][pos].reshape(pos.sum(),-1)
                assert np.isfinite(p).all();examples+=len(a['labels'])
                overlaps.extend(np.sum(p*y,axis=1)/np.maximum(np.linalg.norm(p,axis=1)*np.linalg.norm(y,axis=1),1e-12))
                errors.extend(np.sum((p-y)**2,axis=1)/np.maximum(np.sum(y*y,axis=1),1e-12))
    if not examples:raise FileNotFoundError('Restore the GW test archive first')
    return dict(domain='gw',device=device,model='extra-trained waveform expert',examples=examples,positive_examples=len(overlaps),
        checkpoint_sha256=digest(checkpoint),overlap=float(np.mean(overlaps)),normalized_mse=float(np.mean(errors)))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',type=Path,required=True)
    p.add_argument('--domain',choices=['acoustic','gw'],default='acoustic');p.add_argument('--device',default='cpu');p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.project.resolve();destination=a.output.resolve()
    for protected in ['data','code','reports','release']:
        if destination.is_relative_to(root/protected):raise ValueError('--output must not overwrite frozen release folders; use a new evaluation_outputs directory')
    if destination.exists():raise FileExistsError('Choose a new output filename')
    r=acoustic(root,a.device) if a.domain=='acoustic' else gw(root,a.device)
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
