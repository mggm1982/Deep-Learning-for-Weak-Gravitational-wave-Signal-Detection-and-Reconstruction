# PHC351 — running the code, evaluating results and understanding the models

This guide covers the released GW experiment and the improved acoustic experiment. It uses the seven existing Drive folders; there is no separate professor-submission directory to restore.

## 1. Choose the entry point

**Colab:** open `Code/Acoustic_improvement_v2/PHC351_Acoustic_Improvement_v2.ipynb` for the selected acoustic detector/reconstructor. Open `Code/Training_pipeline_v1/PHC351_MoE_Training.ipynb` for the GW and corrected ESC baseline experiments. Their restore cells verify archive hashes and write inference outputs to the existing Drive Results folders. `PHC351_Rebuild_v2.ipynb` is for the original 3,000-example dataset. `PHC351_Project_legacy.ipynb` is an historical exploratory notebook, not the final training entry point.

**Local or Colab command line:** use `restore_submission.py` and `evaluate_submission.py` as described below. These new helpers were tested against the released archives and checkpoints. They do not train models or reselect operating thresholds during evaluation.

## 2. Install dependencies

Use Python 3.12 and a fresh virtual environment. Download and extract `Code/PHC351_Code_and_Dependencies.zip` into a local directory called `PHC351`. It contains source, guides and dependency manifests; trained weights and datasets remain in their own Drive folders.

```sh
cd PHC351
python3 -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell alternative: .venv\Scripts\Activate.ps1
python -m pip install -r code/training/requirements.txt
```

`Env_Setup/requirements_training.txt` is the same direct dependency list. `requirements_submission.txt` records the exact direct-package versions in the environment that produced the released experiment. It is a provenance snapshot, not a guarantee that identical wheels exist on every operating system/GPU. Install the appropriate PyTorch build for your platform if required. LALSuite supports the waveform-generation/rebuild path; ordinary selected-model inference uses the released tensors and weights.

## 3. Restore from the existing Drive tree

Download/sync the project folder locally, or mount it in Colab with `drive.mount('/content/drive')`. Pass the real project-root path, including any trailing space if your copy has one. In Colab:

```sh
python code/submission_tools/restore_submission.py \
  --drive-root "/content/drive/MyDrive/Deep Learning for Detection and Reconstruction of Gravitational-Wave Signals" \
  --output /content/PHC351_work \
  --mode evaluation
```

On a laptop, replace these two paths with your downloaded Drive root and a **separate** local working directory. The output must be outside the frozen Drive project tree. If you downloaded the two helpers separately from Code, run `python restore_submission.py ...` instead. `--list` shows the plan; `--verify-only` hashes the selected archives without extracting them.

Evaluation mode restores 15 release archives: code, both-domain baseline checkpoints, improved acoustic checkpoints, result records/predictions, metadata, and the GW/ESC/FSD test shards. Training mode also restores the prepared train and validation shards. Add `--include-sources` for the original ESC/FSD source recordings needed for regeneration and the duplicate audit.

The helper handles the existing trailing-space folder names, checks each archive SHA-256, validates extraction paths and reads each member to EOF to check its CRC. It refuses to replace an existing working file with different contents. Use a fresh output directory when restoring a different revision. It writes `RESTORE_VERIFICATION.json` in the new working directory. It does not download data or modify the Drive source folders.

The resulting working tree has `code/`, `data/` and `reports/`. Model weights live under `reports/training_v1/` and `reports/improvement_v2/` in this **runtime** tree because the existing Python scripts resolve them there. In Drive, the checkpoint ZIPs remain under **Trained Models**. These two layouts serve storage and execution respectively.

## 4. Evaluate the frozen selected acoustic models

Run the helper copied with the code bundle, using the restored working directory:

```sh
python code/submission_tools/evaluate_submission.py \
  --project /content/PHC351_work --domain acoustic --device cpu \
  --output /content/PHC351_work/evaluation_outputs/acoustic_replay.json
```

Use `--device cuda` when a compatible CUDA runtime is available, or `mps` on a supported Mac. CPU was used for verification of this helper. Choose a new output filename for each run; existing outputs are not overwritten. The command processes all 1,000 held-out acoustic mixtures. It checks checkpoint digests, output shape, finite values, reconstruction/residual consistency and that the frozen evaluation plan remains unchanged.

Expected released results at the fixed threshold **0.8398472984240973**:

| Quantity | Released result |
|---|---:|
| Accuracy | 0.810 |
| Recall | 0.756 |
| Precision | 0.847534 |
| Noise-window FPR | 0.136 |
| ROC AUC | 0.899928 |
| TP / FN / FP / TN | 378 / 122 / 68 / 432 |
| Selected reconstruction overlap | 0.757744 |
| Selected reconstruction normalised MSE | 0.472459 |

The CPU replay reproduced these values to reported precision. Small numerical differences can occur with different libraries/devices. This is reproduction of the already released test result, not another independent test cohort. Do not use this command's outputs to tune the published threshold.

`code/improvement_v2/evaluate_locked.py` is the original first-evaluation script. It intentionally refuses to run when `fresh_test_results.json` already exists, and can perform additional pre-test training/selection before creating a new plan. Do not delete that guard or use this script for routine replay. The new helper uses the existing selected plan without overwriting it.

## 5. Evaluate GW reconstruction

```sh
python code/submission_tools/evaluate_submission.py \
  --project /content/PHC351_work --domain gw --device cpu \
  --output /content/PHC351_work/evaluation_outputs/gw_replay.json
```

This evaluates the strongest released GW control, `gw_augmented/wave_finetune_best.pt`, on 600 test windows. Reconstruction statistics use the 300 positive injections: overlap **0.870272** and normalised MSE **0.225023**. The restored-archive replay reproduced these values. The GW joint model has overlap 0.865278 and NMSE 0.229965; fusion did not outperform the extra-trained waveform control. The complete comparison is in `Results/MoE_training_v1/results_summary.json`.

## 6. Run inference on individual prepared shards

From the restored working directory:

```sh
cd /content/PHC351_work
mkdir -p evaluation_outputs
python code/improvement_v2/infer_selected.py \
  --input data/acoustic_v2_fsd/test_000.npz \
  --output evaluation_outputs/acoustic_predictions.npz --device cpu
python code/training/infer.py \
  --checkpoint reports/training_v1/gw_augmented/wave_finetune_best.pt \
  --input data/gw_augmented_v3/test_000.npz \
  --domain gw --output evaluation_outputs/gw_predictions.npz --device cpu
```

Acoustic input: finite mono float arrays `X` with shape `(N,16384,1)` and `sample_rate=8192`. GW augmented input: `(N,8192,1)` and `sample_rate=2048`. NPZ files are numeric and opened with `allow_pickle=False`.

Acoustic output includes `reconstruction`, `estimated_noise`, `detection_score`, `detection`, `threshold`, `sample_rate`, and selected-model names. The helper uses common input-derived RMS gain internally and restores the reconstruction's input amplitude units. GW inference also returns `expert_weights` when applicable; a single waveform expert has no learned fusion weights.

The released shards are already conditioned. Raw microphone files and raw strain are **not** interchangeable with these tensors. External audio needs resampling, mono conversion, windowing and compatible band-limiting; the nominal adapter is an offline 30–3700 Hz bandpass, whereas the synthetic mixtures have recorded per-mixture filter settings. No raw-field adapter has been field validated here. GW inputs/targets must share the recorded background PSD, whitening and filtering operator. Never independently normalise targets.

To keep new outputs directly in Drive, set `--output` to a new filename under the existing Results folder; retain the released results and immutable plans. The provided Colab notebooks do this automatically.

## 7. What was trained?

The domains use separate models and data. They share a decomposition/fusion design idea; they do not fuse gravitational waves with human sounds.

- **GW/corrected acoustic baselines:** waveform encoder/decoder with residual temporal convolution blocks; a compact complex-STFT spectral expert; fixed-average and learned-gate fusion; frozen-expert fusion followed by joint fine-tuning; an extra-trained single-expert control.
- **Improved acoustic experts:** waveform TCN and complex-mask spectral U-Net with skip connections and temporal attention. Both process representations of the same microphone signal.
- **Learned fusion:** input statistics, expert features and estimated quality guide softmax weights; the true reference SNR is not an inference input. Joint training combines reconstruction, silence, spectral, noise, consistency and detection losses.
- **Additional detector:** a 40-band log-mel CNN, bidirectional GRU and attention pooling produces a detection logit.
- **Selected detector:** equal mean of six raw logits: three joint models and three base CNN–BiGRU detectors, followed by sigmoid and the validation-selected threshold. This is different from the gate's reconstruction weights.
- **Selected reconstructor:** `35162_joint_recall`. It is selected separately from the detector. Mean spectral weight is about 94.5%, so balanced expert specialisation has not been established.

The three fine-tuning seeds share pretrained initialisation. CRED, EQTransformer and DeepDenoiser are cited architectural influences, not original-model reproductions trained here. See `Trained Models/MODEL_CARD.md` for intended use and limitations.

## 8. Repeat training in a separate experiment

First restore with `--mode training --include-sources` to a **new** working directory. The restored checkpoints, completion markers and results are the published reference; rerunning scripts against them may simply reuse cached stages. Do not remove markers from the shared Drive release.

For a new GW/corrected-ESC baseline run, choose a new output directory:

```sh
PHC351_SKIP_ORIGINAL_PILOT=1 PHC351_OUTPUT_ROOT=/content/PHC351_new_baselines \
  python code/training/run_experiments.py
PHC351_OUTPUT_ROOT=/content/PHC351_new_baselines \
  python code/training/budget_baselines.py
```

These commands run from the restored working directory. They skip the original 3,000-example pilot, whose separate NPZ files are not included by the archive restore helper. To repeat that pilot, copy its train/validation/test NPZs and metadata into `data/rebuilt_v2/` first, following `README_GW_DATASET_REBUILD.md`.

For a fresh acoustic v2 development run, preserve the restored v2 results elsewhere **in the local working copy**, then create a new `reports/improvement_v2/`. Retain the v1 corrected acoustic checkpoint under `reports/training_v1/acoustic_corrected/` for the legacy control. The implementation's v2 output location is fixed relative to its code, so use an isolated project copy rather than changing the published folder.

```sh
mkdir -p reference_results
mv reports/improvement_v2 reference_results/published_improvement_v2
mkdir -p reports/improvement_v2
python code/improvement_v2/audit_audio_duplicates.py
python code/improvement_v2/train_improved.py --pretrain
python code/improvement_v2/train_improved.py --pretrain-crnn
python code/improvement_v2/run_development.py
```

`run_development.py` rebuilds/checks the FSD mixtures from restored sources and completes seeds 35161, 35162 and 35163 before freezing development choices. The original final-evaluation path is then `python code/improvement_v2/evaluate_locked.py`; it also completes the predeclared classifier-tail stage before loading test data. Summaries and figures can be regenerated with `summarize_results.py` and `create_paper_figures.py`. These training commands are documented from the implementation, not newly rerun during the directory audit.

Reusing the released test set is replication of this benchmark. Any further selection/novelty study needs an independently reserved test set. Source regeneration also needs the recorded licences and manifests. Full original GW raw reconstruction uses the H1 parts in `Datasets/Gwosc` and the separate v2 rebuild notebook; it is not necessary for evaluating the released weights.

## 9. Troubleshooting

- **Folder not found:** point `--drive-root` to the folder containing Code, Datasets, Results, Reports, Trained Models, Env_Setup and Library Repositories. Mount/sync Drive first.
- **Hash mismatch:** stop and obtain the matching original archive. Do not edit a release hash to suppress the error.
- **Existing file differs:** use a fresh restore output. Do not mix historical and improved checkpoints/data versions.
- **`X` absent from an NPZ:** conditioning metadata are not input shards. Select `test_000.npz`, not `test_conditioning.npz`.
- **Out of memory:** use CPU or individual-shard inference. Full replay retains the test tensors; it does not need a GPU.
- **Wrong sample rate/shape:** use the appropriate domain dataset and preserve time/channel axes; do not reshape arbitrary sensor data to satisfy an assertion.

Public sound-category proxies, weak foreground references and synthetic mixtures do not establish a reliable survivor detector. The current system is offline, does not localise a person, and produced 79 merged alerts in a short continuous-background diagnostic. See the model card before interpreting its scores operationally.
