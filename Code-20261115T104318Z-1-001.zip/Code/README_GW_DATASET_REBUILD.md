# PHC351 reconstruction dataset v2

This is an H1 single-detector baseline with 1,500 independently parameterized
IMRPhenomD waveforms and 1,500 noise-only examples. It replaces the original
eight reused 4-second backgrounds with quality-checked windows from 4,096 seconds
of real H1 strain. All masses are detector-frame masses. Waveforms have zero spin,
component masses 20–50 solar masses, isotropic inclination, random phase, and a
random linear combination of plus/cross polarization. This simplified detector
response does not implement a coherent H1/L1 sky projection.

## Data layout and use

Each NPZ shard contains float32 `X` and `y` with shape `(n, 16384, 1)`, int8
binary `labels`, string `sample_ids`, and `sample_rate=4096`. Use
`np.load(path, allow_pickle=False)`. A positive target is the conditioned injected
waveform; a negative target is exactly zero. Inputs and targets share units and
time coordinates. No separate per-example or per-target standardization is used.
Convert `(batch,time,channels)` to `(batch,channels,time)` for PyTorch if needed.

- Train: 2,100 examples (1,050 positive + 1,050 negative).
- Validation: 450 examples (225 + 225).
- Test: 450 examples (225 + 225); reserve for final model evaluation.

Concatenate shards within a split only. Do not randomly split the combined data
again. Use the validation split during model development. Keep test data fixed.
These 3,000 examples are not 3,000 independent noise realizations: outputs can
overlap within each split. They come from one recording, so later evaluation
on different observing times is still needed to assess wider generalization.

`manifest.json` records provenance, source and shard SHA256 values, configuration,
split time ranges, dependencies, counts and SNR convention. `samples.jsonl` maps
every sample ID to its noise interval, waveform parameters, scale, arrival peak,
SNR, and validation metrics. Split conditioning NPZ files preserve the exact
background PSD, whitening kernel, and Butterworth coefficients.

## Conditioning and SNR

Split the source timeline first into [0,2400), [2400,3232), [3232,4096) seconds.
Within each split, reserve 128 seconds for a median Welch PSD using 4-second
Hann windows with 50% overlap. Model windows never use this PSD region; a
4-second guard separates them. Require DATA/CBC CAT1/2/3 quality flags and no
CBC, burst, or detector-characterization hardware injections. Exclude at least
32 seconds either side of GW150914. Non-transient CW hardware injection flags
are not vetoed; the selected injection bits are documented in code.

Sample unique 12-second contexts on a 1-second grid. Neighboring output windows
may overlap by up to 75%; no context or PSD accesses another split. Position the
waveform amplitude peak at 2.25–2.75 seconds within a 4-second retained window.
Verify >99% of the original time-domain waveform energy is inside that window.

Inject in float64 physical strain units. Set the injected waveform's optimal SNR
between 5 and 20 using `rho² = 4 sum(|FFT(h)/fs|² / PSD) df` over 30–500 Hz.
SNR denotes the optimal *preconditioning* injection SNR, not the observed maximum
matched-filter SNR of signal plus noise. The reference 400 Mpc amplitude is
rescaled to attain SNR; it is not a preserved astrophysical distance distribution.

Whiten using an ASD inverse transfer with sqrt(2/fs) normalization, smoothly
restricted to 25–550 Hz and truncated to a 4-second symmetric FIR with a Tukey
taper. Apply an order-4 zero-phase 30–500 Hz Butterworth band-pass afterward.
Apply this same linear operator to the mixture and clean waveform. Discard
4 seconds at each edge of the 12-second context. No independent target scaling,
PSD estimation from injected mixtures, or target filtering fitted to test labels
is involved. Conditioned target L2 norm need not equal preconditioning SNR because
the filter is tapered and finite. Targets represent band-limited conditioned
signals; full-band physical strain is not recoverable from these targets alone.

## Reproduce locally

Use Python 3.12 and the versions in `requirements.txt`. Download the public source:
https://gwosc.org/GW150914data/H-H1_LOSC_4_V2-1126257414-4096.hdf5

```
python code/rebuild_dataset.py --source data/raw/H-H1_LOSC_4_V2-1126257414-4096.hdf5 --output data/rebuilt_v2
python code/validate_dataset.py --source data/raw/H-H1_LOSC_4_V2-1126257414-4096.hdf5 --output data/rebuilt_v2
python code/plot_dataset.py --output data/rebuilt_v2 --figures reports/v2_figures
```

The validator reads every saved array, regenerates every positive waveform from
its parameters, reconstructs all inputs from the raw noise, checks SNR and timing,
checks source separation and quality masks, checks all file hashes, and writes
`validation_report.json`. A successful dataset must contain at least 1,500
positive and 1,500 negative examples. The builder's `--smoke` option produces a
tiny diagnostic build that intentionally cannot pass that final count requirement.

## Google Drive

Original H1/L1 32-second source files and the event reference windows are retained.
The old H1/L1 preprocessing arrays, single simulated waveform, and 100-waveform
archive are obsolete once the replacement has passed validation and uploaded.
Training, validation, and test shards are saved in their dedicated v2 folders;
conditioning, manifests, quality masks and the sample index are saved together in
`Datasets/Preprocessing data/Reconstruction_v2_metadata`.

`PHC351_Rebuild_v2.ipynb` mounts Drive and loads the uploaded code and dataset.
Its optional rebuild cell writes to a new run directory instead of replacing
the validated release. Keep `validation_report.json` and Drive release metadata
with the dataset. See `drive_release.json` for observed Drive IDs/URLs.

References: https://gwosc.org/events/GW150914/ ; https://gwosc.org/techdetails/ ;
https://lscsoft.docs.ligo.org/lalsuite/lalsimulation/

The Drive connector limits individual uploads to 100 MiB. The new raw source is
stored losslessly as `H1_background_v2.part000` and `.part001` with
`source_parts.json` in `Datasets/Gwosc `. The notebook assembles these into its
local Colab cache and verifies both part hashes and the complete source hash
before a rebuild or full revalidation. Released data arrays remain directly in Drive.
