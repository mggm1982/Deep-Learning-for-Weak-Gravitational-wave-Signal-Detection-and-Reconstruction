"""Verify release ZIPs in the existing Drive tree and restore a local working copy."""
import argparse, hashlib, json, shutil, zipfile
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()

def named(parent,name):
    choices=[p for p in parent.iterdir() if p.is_dir() and p.name.strip()==name]
    if len(choices)!=1:raise ValueError(f'Expected one {name!r} folder under {parent}; found {choices}')
    return choices[0]

def make_plan(root,mode,include_sources=False):
    data=named(root,'Datasets');train=named(data,'Training data');test=named(data,'Testing data')
    meta=named(data,'Preprocessing data');code=named(root,'Code');results=named(root,'Results');models=named(root,'Trained Models')
    v1=json.loads((meta/'Training_pipeline_v1_metadata/training_release.json').read_text())
    v2=json.loads((results/'Acoustic_improvement_v2/drive_release.json').read_text())
    folders1=dict(code=code/'Training_pipeline_v1',gw_train=train/'GW_augmented_v3',gw_test=test/'GW_augmented_v3',
        audio_train=train/'Acoustic_v1',audio_test=test/'Acoustic_v1',metadata=meta/'Training_pipeline_v1_metadata',
        audio_sources=data/'Acoustic_sources_ESC50',models=models/'MoE_training_v1',results=results/'MoE_training_v1')
    folders2=dict(code=code/'Acoustic_improvement_v2',models=models/'Acoustic_improvement_v2',results=results/'Acoustic_improvement_v2',
        train=train/'Acoustic_FSD_v2',test=test/'Acoustic_FSD_v2',sources=data/'FSD50K_sources_v2',metadata=meta/'Acoustic_improvement_v2_metadata')
    plan=[]
    for e in v1['files']:
        kind=e.get('kind');group=e.get('group','');key=e.get('folder_key')
        if kind not in ['data_archive','code_bundle','checkpoint_bundle','results_bundle']:continue
        if group=='audio_sources' and not include_sources:continue
        if mode=='evaluation' and group in ['gw_train','gw_validation','audio_train','audio_validation']:continue
        if kind=='code_bundle':dest='.'
        elif kind in ['checkpoint_bundle','results_bundle']:dest='reports/training_v1'
        elif group=='audio_sources':dest='data/acoustic_sources'
        else:dest='data/gw_augmented_v3' if group.startswith('gw_') else 'data/acoustic_v1'
        plan.append(dict(source=str(folders1[key]/e['file_name']),sha256=e['sha256'],destination=dest))
    for e in v2['archives']:
        key=e['folder']
        if key=='train' and mode=='evaluation':continue
        if key=='sources' and not include_sources:continue
        plan.append(dict(source=str(folders2[key]/Path(e['file']).name),sha256=e['sha256'],destination='.'))
    return plan

def restore(plan,output,verify_only=False):
    records=[]
    for e in plan:
        source=Path(e['source']);actual=digest(source)
        if actual!=e['sha256']:raise ValueError(f'Archive SHA256 mismatch: {source}')
        record=dict(archive=source.name,sha256=actual,status='VERIFIED')
        if not verify_only:
            target=(output/e['destination']).resolve()
            target.relative_to(output.resolve())
            with zipfile.ZipFile(source) as archive:
                for info in archive.infolist():
                    dest=(target/info.filename).resolve();dest.relative_to(output.resolve())
                    if info.is_dir():continue
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    with archive.open(info) as reader:
                        blob=reader.read()  # Reading to EOF checks member CRC.
                    if dest.exists() and hashlib.sha256(dest.read_bytes()).digest()!=hashlib.sha256(blob).digest():
                        raise ValueError(f'Existing file differs; choose a fresh --output: {dest}')
                    if not dest.exists():dest.write_bytes(blob)
                record['members']=len(archive.infolist())
        records.append(record);print(record['status'],source.name,flush=True)
    if not verify_only:
        output.mkdir(parents=True,exist_ok=True)
        (output/'RESTORE_VERIFICATION.json').write_text(json.dumps(records,indent=2)+'\n')
    return records

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--drive-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--mode',choices=['evaluation','training'],default='evaluation')
    p.add_argument('--include-sources',action='store_true');p.add_argument('--verify-only',action='store_true');p.add_argument('--list',action='store_true')
    a=p.parse_args();root=a.drive_root.resolve();out=a.output.resolve()
    if out==root or out.is_relative_to(root):raise ValueError('--output must be outside the frozen Drive project tree')
    plan=make_plan(root,a.mode,a.include_sources)
    if a.list:print(json.dumps(plan,indent=2));return
    restore(plan,out,a.verify_only)
    if not a.verify_only:
        # New submission helpers are separate from the immutable historical release ZIPs.
        dest=out/'code/submission_tools';dest.mkdir(parents=True,exist_ok=True)
        for source in (named(root,'Code')).glob('*_submission.py'):shutil.copy2(source,dest/source.name)
    print(f'PASS: {len(plan)} archives; mode={a.mode}; verify_only={a.verify_only}')
if __name__=='__main__':main()
