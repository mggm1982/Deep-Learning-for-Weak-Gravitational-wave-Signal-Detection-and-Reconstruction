# PHC351: compact decomposition experts, soft fusion and joint training

Acoustic v1.1 correction: every mixture and its target receive the same
mixture-derived gain, making input RMS 0.1 for both labels. This removes the
fixed-background-loudness label shortcut in the discarded first acoustic run.
The corrected experiment is `acoustic_corrected`; `acoustic` is a development
diagnostic and is excluded from the scientific comparison/checkpoint release.

This release implements and executes a single-seed research training pipeline in
two separate domains. It is not a field-validated survivor detector, and it is not
a reproduction of the complete EQTransformer/CRED/DeepDenoiser architectures.

## Models and stages

- Waveform expert: learned analysis/synthesis filterbank with residual dilated
  temporal convolutions and separate signal/noise masks. Polyphase channels
  initialize a waveform-preserving analysis/synthesis path.
- Spectral expert: complex STFT masking with a small 2D CNN, followed by iSTFT.
  It estimates separate signal and noise masks and a binary detection logit.
- Soft mixture: a learned gate combines both experts using only observable
  input features: spectral band fractions, RMS, crest factor, temporal variation,
  spectral flatness, expert-output strength ratios, disagreement and detection
  scores. Neither clean targets nor true injection SNR enter the inference gate.
- Training sequence: experts independently; frozen experts + trained gate and
  detector; then joint fine-tuning at a lower learning rate. A fixed-average
  ensemble is included as an ablation.
- Joint loss: per-positive energy-normalized waveform MSE; negative-output
  suppression; complex multi-resolution STFT error; noise-reconstruction error;
  signal+noise consistency; binary detection loss. Amplitudes are preserved in
  common input/target units rather than independently normalized.

## Data and validation

The original 3000-example GW release is preserved. A 16-positive high-energy
diagnostic verifies learning; a six-epoch pilot uses its complete training split
and original validation split. Test data are not used for stage selection.

Expanded GW v3: 7200 examples (6000 train / 600 validation / 600 test), balanced
between 3600 independently generated IMRPhenomD waveforms and 3600 negatives.
Merger placement spans 1.25–3.25 seconds in a 4-second window. A quarter of the
backgrounds receive controlled sine-Gaussian transient perturbations in raw
strain before shared conditioning. The nominal optimal injection SNR is 5–20
against the reserved background PSD; transient augmentation adds interference.
The existing 4096-second H1 recording is reused within its disjoint source
splits. More mixtures do not mean more independent observing times. Shared
anti-aliased resampling changes 4096 Hz to 2048 Hz while retaining the 30–500 Hz
analysis band. Input/target shape is (8192,1).

Acoustic v1: 7200 mixtures (6000 / 600 / 600), created from a pinned 320-clip
ESC-50 subset. Foreground categories: coughing, crying_baby, door_wood_knock.
Background: rain, wind, engine, helicopter, hand_saw. Knock-like sounds are a
proxy event class, not proof that a human or survivor is present. Source audio
may already contain ambient sound. Targets are propagated source excerpts,
not anechoic ground truth. Mixtures span -10 to +10 dB RMS SNR, have controlled
shifts and synthetic propagation responses, and use 2 seconds at 8192 Hz:
(16384,1). Audio RMS SNR in dB is not the GW optimal SNR convention.

Original ESC folds 1–3 / 4 / 5 are assigned before mixing. Source-file groups
cannot cross splits. The number of augmented mixtures exceeds the number of
independent original recordings. The original LICENSE, per-clip attribution,
pinned commit, hashes and repository metadata are preserved. ESC-50 data are
CC BY-NC 3.0 and this release is for academic/non-commercial research.

Construction checks validate every shard, sample ID, shape, finite value and
negative/positive target. `verify_training_data.py` independently reconstructs
every saved input and clean target from original source recordings and saved
parameters. It checks float32 tolerances and independently recomputes SNR.

## Experiments and use

```
python code/training/download_audio.py
python code/training/build_training_data.py gw
python code/training/build_training_data.py acoustic
python code/training/verify_training_data.py gw
python code/training/verify_training_data.py acoustic
python code/training/run_experiments.py
```

Use `PHC351_OUTPUT_ROOT` to select an output directory (for example a mounted
Drive run folder). CUDA is used when available, then MPS, then CPU. Seed 35143,
AdamW, gradient clipping and validation-based early stopping are recorded.
Expert stages allow 15 epochs; frozen fusion and joint fine-tuning allow 7 each.
The pilot runs 6 epochs. Stage completion markers allow completed stages to be
reused; use a fresh output directory for a fresh experiment or seed change.

`*_best.pt` contains best validation-selected weights. `*_history.json` records
the learning curves. `comparison.json` reports held-out results, including input
and zero-output baselines. Detection thresholds are chosen on validation noise
at a nominal 5% window false-positive fraction; test fractions can differ.
This is not an operational false-alerts-per-hour measurement or calibration.

```
python code/training/infer.py --checkpoint RUN/gw_augmented/joint_best.pt --input data/gw_augmented_v3/test_000.npz --domain gw --output predictions.npz
```

Inference expects the correctly conditioned dataset format, not raw sensor or
GW strain. It returns recovered signal, estimated noise, detection score and
expert weights. The acoustic model does not localize people. The models are
trained separately by domain; cross-domain weight transfer has not been tested.

## Drive packaging and paper scope

Lossless ZIP archives contain the NPZ shards; each ZIP is below the connector's
100 MiB limit. Training/validation archives go under Training data, held-out
archives under Testing data, metadata under Preprocessing data, original audio
under Acoustic_sources_ESC50, weights under Trained Models, and experiment
outputs under Results/Reports. `archive_index.json` preserves each archive/member
hash. The Colab notebook assembles a local working cache from Drive and can save
new training checkpoints directly to a fresh mounted-Drive run directory.

Results are a single-seed pilot, not a publication-ready novelty claim. Report
gate dominance or collapse, negative transfer, and cases where a simpler expert
wins. Additional seeds, observing times, difficult noise, meaningful false-alert
measurements and representative rescue recordings are needed for stronger
generalization and operational claims. The first diagnostic architecture failed
the stronger small-batch reconstruction criterion; its log is retained as a
failed development diagnostic, not an experiment result.

References:
https://github.com/karolpiczak/ESC-50
https://arxiv.org/abs/1809.07454
https://arxiv.org/abs/1811.02695
